﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shoes
{
    public class Param
    {
        public ShoesDBDataSet.UserRow userRow;
        public bool auth = false;
    }
}
